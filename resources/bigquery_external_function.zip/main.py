# https://cloud.google.com/bigquery/docs/remote-function-tutorial

import flask
import os
import urllib.request
import functions_framework
from google.cloud import vision
from google.api_core.client_options import ClientOptions
from google.cloud.speech_v2 import SpeechClient
from google.cloud.speech_v2.types import cloud_speech

# Entry point (we recevice an element named "userDefinedContext").  The userDefinedContext 
# tells us which method to call
@functions_framework.http
def bigquery_external_function(request: flask.Request) -> flask.Response:
    print("BEGIN: bigquery_external_function")
    request_json = request.get_json()
    print("request_json: ", request_json)
    mode = request_json['userDefinedContext']['mode']
    print("mode: ", mode)
    calls = request_json['calls']
    print("calls: ", calls)
    print("END: bigquery_external_function")
    if mode == "extract_text_uri":
        return extract_text_uri(request)

@functions_framework.http
def extract_text_uri(request: flask.Request) -> flask.Response:
    try:
        project_id = os.environ['PROJECT_ID']
        region = os.environ['ENV_CLOUD_FUNCTION_REGION']
        client = SpeechClient(client_options=ClientOptions(api_endpoint=f"{region}-speech.googleapis.com"))
        config = cloud_speech.RecognitionConfig(
            auto_decoding_config=cloud_speech.AutoDetectDecodingConfig(),
            language_codes=["en-US"],
            model="chirp"
        )
        calls = request.get_json()['calls']
        replies = []
        for call in calls:
            uri=call[0]
            print("uri: ", uri)
            content = urllib.request.urlopen(uri).read()
            request = cloud_speech.RecognizeRequest(
                recognizer=f"projects/{project_id}/locations/{region}/recognizers/_",
                config=config,
                content=content)
            response = client.recognize(request=request)
            partial_result = ""
            for result in response.results:
                partial_result = partial_result + result.alternatives[0].transcript
            replies.append(partial_result)    
        return flask.make_response(flask.jsonify({'replies': replies}))
    except Exception as e:
        return flask.make_response(flask.jsonify({'errorMessage': str(e)}), 400)